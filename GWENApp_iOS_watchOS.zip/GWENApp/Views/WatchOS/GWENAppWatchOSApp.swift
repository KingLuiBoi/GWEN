//
//  GWENAppWatchOSApp.swift
//  GWENAppWatchOS
//
//  Created by Manus on 5/14/25.
//

import SwiftUI

@main
struct GWENAppWatchOSApp: App {
    var body: some Scene {
        WindowGroup {
            WatchContentView()
        }
    }
}

